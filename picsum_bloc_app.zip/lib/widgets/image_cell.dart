import 'package:flutter/material.dart';
import '../models/picsum_image.dart';
import 'package:google_fonts/google_fonts.dart';

class ImageCell extends StatelessWidget {
  final PicsumImage image;
  const ImageCell({Key? key, required this.image}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final screenW = MediaQuery.of(context).size.width;
    final aspect = image.width > 0 ? image.height / image.width : 1.0;
    final calculatedHeight = screenW * aspect;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 12.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: screenW,
            height: calculatedHeight,
            child: Image.network(
              image.downloadUrl,
              fit: BoxFit.cover,
              width: screenW,
              height: calculatedHeight,
              loadingBuilder: (context, child, progress) {
                if (progress == null) return child;
                return Container(
                  color: Colors.grey[200],
                  child: const Center(child: CircularProgressIndicator()),
                );
              },
              errorBuilder: (context, err, st) => Container(
                width: screenW,
                height: calculatedHeight,
                color: Colors.grey[300],
                child: const Icon(Icons.broken_image, size: 48),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            image.title,
            style: GoogleFonts.montserrat(fontWeight: FontWeight.w600, color: Colors.black87, fontSize: 16),
          ),
          const SizedBox(height: 4),
          Text(
            image.description,
            style: GoogleFonts.montserrat(fontWeight: FontWeight.w400, color: Colors.grey[700], fontSize: 14),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}
