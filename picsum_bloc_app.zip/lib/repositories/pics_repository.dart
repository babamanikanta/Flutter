import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/picsum_image.dart';

class PicsRepository {
  final http.Client _client;

  PicsRepository({http.Client? client}) : _client = client ?? http.Client();

  Future<List<PicsumImage>> fetchImages({int limit = 10}) async {
    final uri = Uri.parse('https://picsum.photos/v2/list?limit=$limit');
    final resp = await _client.get(uri);
    if (resp.statusCode == 200) {
      final List<dynamic> jsonList = json.decode(resp.body);
      return jsonList.map((e) => PicsumImage.fromJson(e)).toList();
    } else {
      throw Exception('Failed to fetch images: ${resp.statusCode}');
    }
  }
}
