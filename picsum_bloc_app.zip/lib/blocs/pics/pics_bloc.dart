import 'package:flutter_bloc/flutter_bloc.dart';
import 'pics_event.dart';
import 'pics_state.dart';
import '../../repositories/pics_repository.dart';

class PicsBloc extends Bloc<PicsEvent, PicsState> {
  final PicsRepository picsRepository;
  PicsBloc({required this.picsRepository}) : super(const PicsState()) {
    on<PicsRequested>((event, emit) async {
      emit(state.copyWith(status: PicsStatus.loading));
      try {
        final imgs = await picsRepository.fetchImages(limit: event.limit);
        emit(state.copyWith(status: PicsStatus.success, images: imgs));
      } catch (e) {
        emit(state.copyWith(status: PicsStatus.failure, message: e.toString()));
      }
    });
  }
}
