import 'package:equatable/equatable.dart';
abstract class PicsEvent extends Equatable {
  const PicsEvent();
  @override List<Object?> get props => [];
}

class PicsRequested extends PicsEvent {
  final int limit;
  const PicsRequested({this.limit = 10});
}
