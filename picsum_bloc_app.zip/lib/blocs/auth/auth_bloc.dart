import 'package:flutter_bloc/flutter_bloc.dart';
import 'auth_event.dart';
import 'auth_state.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  AuthBloc() : super(const AuthState()) {
    on<AuthEmailChanged>((event, emit) {
      emit(state.copyWith(email: event.email, isEmailValid: _validateEmail(event.email)));
    });

    on<AuthPasswordChanged>((event, emit) {
      emit(state.copyWith(password: event.password, isPasswordValid: _validatePassword(event.password)));
    });

    on<AuthSubmitted>((event, emit) async {
      final emailValid = _validateEmail(event.email);
      final passwordValid = _validatePassword(event.password);
      if (!emailValid || !passwordValid) {
        emit(state.copyWith(
            isEmailValid: emailValid,
            isPasswordValid: passwordValid,
            status: AuthStatus.failure,
            message: 'Invalid credentials format'));
        return;
      }

      emit(state.copyWith(status: AuthStatus.validating));

      // Simulate authentication delay (replace with real API auth if desired)
      await Future.delayed(const Duration(seconds: 1));

      // For demo: accept any email/password that pass validation
      emit(state.copyWith(status: AuthStatus.success));
    });
  }

  bool _validateEmail(String email) {
    final emailRegex = RegExp(r"^[^\s@]+@[^\s@]+\.[^\s@]+\$");
    return emailRegex.hasMatch(email);
  }

  bool _validatePassword(String password) {
    final passRegex = RegExp(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*\W).{8,}\$');
    return passRegex.hasMatch(password);
  }
}
