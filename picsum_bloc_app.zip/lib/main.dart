import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';

import 'blocs/auth/auth_bloc.dart';
import 'blocs/pics/pics_bloc.dart';
import 'repositories/pics_repository.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';

void main() {
  final PicsRepository picsRepository = PicsRepository();
  runApp(MyApp(picsRepository: picsRepository));
}

class MyApp extends StatelessWidget {
  final PicsRepository picsRepository;
  const MyApp({Key? key, required this.picsRepository}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<AuthBloc>(
          create: (_) => AuthBloc(),
        ),
        BlocProvider<PicsBloc>(
          create: (_) => PicsBloc(picsRepository: picsRepository),
        ),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Picsum BLoC Demo',
        theme: ThemeData(
          textTheme: GoogleFonts.montserratTextTheme(),
          primarySwatch: Colors.blue,
        ),
        initialRoute: '/',
        routes: {
          '/': (context) => const LoginScreen(),
          '/home': (context) => const HomeScreen(),
        },
      ),
    );
  }
}
