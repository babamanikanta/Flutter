class PicsumImage {
  final String id;
  final String author;
  final String downloadUrl;
  final int width;
  final int height;

  PicsumImage({
    required this.id,
    required this.author,
    required this.downloadUrl,
    required this.width,
    required this.height,
  });

  factory PicsumImage.fromJson(Map<String, dynamic> json) {
    return PicsumImage(
      id: json['id'] as String,
      author: json['author'] as String,
      downloadUrl: json['download_url'] as String,
      width: (json['width'] as num).toInt(),
      height: (json['height'] as num).toInt(),
    );
  }

  String get title => 'Photo by $author';
  String get description => 'Image id: $id • ${width}x$height';
}
