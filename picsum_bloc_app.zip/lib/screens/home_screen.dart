import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../blocs/pics/pics_bloc.dart';
import '../blocs/pics/pics_event.dart';
import '../blocs/pics/pics_state.dart';
import '../widgets/image_cell.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    context.read<PicsBloc>().add(const PicsRequested(limit: 10));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Picsum Images'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => context.read<PicsBloc>().add(const PicsRequested(limit: 10)),
          ),
        ],
      ),
      body: BlocBuilder<PicsBloc, PicsState>(
        builder: (context, state) {
          if (state.status == PicsStatus.loading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state.status == PicsStatus.failure) {
            return Center(child: Text('Failed: ${state.message}'));
          } else if (state.status == PicsStatus.success) {
            final images = state.images;
            return ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 8),
              itemCount: images.length,
              itemBuilder: (context, idx) => ImageCell(image: images[idx]),
            );
          } else {
            return const Center(child: Text('No images yet.'));
          }
        },
      ),
    );
  }
}
